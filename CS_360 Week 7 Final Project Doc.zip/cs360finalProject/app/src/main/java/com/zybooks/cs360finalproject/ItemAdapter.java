package com.zybooks.cs360finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class ItemAdapter extends BaseAdapter {

    DBHelperItems DB;
    Context context;
    String item_names[];
    String item_amounts[];

    LayoutInflater inflater;

    public ItemAdapter(Context ctx, String[] item_names, String[] item_amounts){
        this.context = ctx;
        this.item_names = item_names;
        this.item_amounts = item_amounts;
        inflater = LayoutInflater.from(ctx);
    }
    @Override
    public int getCount() {
        return item_names.length;
    }

    @Override
    public Object getItem(int position) {
        return item_names[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        DB = new DBHelperItems(context);

        convertView = inflater.inflate(R.layout.activity_custom_list_view, null);
        TextView item_name = convertView.findViewById(R.id.textView);
        TextView item_count = convertView.findViewById(R.id.textView2);
        Button minusBtn = convertView.findViewById(R.id.button4);
        Button addBtn = convertView.findViewById(R.id.button5);
        Button deleteBtn = convertView.findViewById(R.id.delete);

        item_name.setText(item_names[position]);
        item_count.setText(item_amounts[position]);

        minusBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String name = item_name.getText().toString();
                int count = Integer.parseInt(item_count.getText().toString());
                DB.minusCount(name,count);
            }
        });

        addBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String name = item_name.getText().toString();
                int count = Integer.parseInt(item_count.getText().toString());
                DB.addCount(name,count);
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String name = item_name.getText().toString();
                DB.delete(name);
            }
        });


        return convertView;
    }
}
