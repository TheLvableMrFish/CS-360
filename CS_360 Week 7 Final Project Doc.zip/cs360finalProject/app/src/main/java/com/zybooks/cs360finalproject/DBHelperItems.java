package com.zybooks.cs360finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelperItems extends SQLiteOpenHelper {

    public static final String DBNAME = "Items.db";

    public DBHelperItems(Context context){super(context, "Items.db", null, 1);}

    public void onCreate(SQLiteDatabase MyDB){
        MyDB.execSQL("create Table items(item_name Text primary key, item_amount INTEGER)");
    }

    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1){
        MyDB.execSQL("DROP Table if exists items");
    }

    public Boolean checkItemName(String item_name){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from items WHERE item_name = ?", new String[] {item_name});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean insertData(String item_name){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item_name", item_name);
        contentValues.put("item_amount", 0);
        long result = MyDB.insert("items", null, contentValues);
        if(result == -1) return false;
        else
            return true;
    }

    public List<String> getAllItemNames(){
        List<String> itemNames = new ArrayList<>();
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT item_name FROM items", null);

        if(cursor.moveToFirst()){
            do {
                String itemName = cursor.getString(cursor.getColumnIndex("item_name"));
                itemNames.add(itemName);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return itemNames;
    }
    public List<String> getAllItemCounts(){
        List<String> itemCounts = new ArrayList<>();
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT item_amount FROM items", null);

        if(cursor.moveToFirst()){
            do {
                String itemCount = cursor.getString(cursor.getColumnIndex("item_amount"));
                itemCounts.add(itemCount);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return itemCounts;
    }

    public Boolean addCount(String item_name, int item_amount){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item_amount", item_amount + 1);
        long result = MyDB.update("items", contentValues, "item_name=?", new String[]{item_name});
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean minusCount(String item_name, int item_amount){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        if(item_amount > 0){
            contentValues.put("item_amount", item_amount - 1);
            long result = MyDB.update("items", contentValues, "item_name=?", new String[]{item_name});
            if(result==-1) return false;
            else
                return true;
        }
        else
            return false;
    }

    public Boolean delete(String item_name){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        long result = MyDB.delete("items", "item_name=?", new String[]{item_name});
        if(result == -1) return false;
        else
            return true;
    }
}
