package com.zybooks.cs360finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateItem extends AppCompatActivity {

    EditText item_name;
    Button create_item;

    DBHelperItems DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_item);

        item_name = findViewById(R.id.itemName);
        create_item = findViewById(R.id.createItem);

        DB = new DBHelperItems(this);
        Intent intent = getIntent();
        String USER_NAME = intent.getStringExtra(MainActivity.USER_NAME);

        create_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = item_name.getText().toString();
                if(name.equals("")) {
                    Toast.makeText(CreateItem.this, "Please enter item name", Toast.LENGTH_SHORT).show();
                }
                else{
                        Boolean checkItem = DB.checkItemName(name);
                        if (!checkItem) {
                            Boolean insert = DB.insertData(name);
                            if(insert){
                                Toast.makeText(CreateItem.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(CreateItem.this, ToolScreen.class);
                                startActivity(intent);
                            }
                        } else {
                            Toast.makeText(CreateItem.this, "This item already exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        });
    }
}