package com.zybooks.cs360finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ToolScreen extends AppCompatActivity {
//    String item_names[] = {"first", "second", "third", "fourth"};
    DBHelper DB;
    DBHelperItems DB2;

    ListView listView;

    FloatingActionButton floatingActionButton;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tool_screen);
        DB = new DBHelper(this);
        DB2= new DBHelperItems(this);
        String item_names[] = DB2.getAllItemNames().toArray(new String[0]);
        String item_amounts[] = DB2.getAllItemCounts().toArray(new String[0]);


        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String userName = intent.getStringExtra(MainActivity.USER_NAME);

        // Call textView element
        // Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.username);
        textView.setText(userName);



        listView = findViewById((R.id.list_container));
        // recent change added item_amounts
        ItemAdapter itemAdapter = new ItemAdapter(getApplicationContext(), item_names, item_amounts);
        listView.setAdapter(itemAdapter);

        floatingActionButton = findViewById(R.id.floatingActionButton);



        if(!DB.getNotifyStatus(userName)){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Android Studio");
            alert.setMessage("Allow notifications");
            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i){
                    DB.updateNotifyStatus(userName, true);
                    Toast.makeText(ToolScreen.this, "Thank you!", Toast.LENGTH_SHORT).show();

                }
            });
            alert.setNegativeButton("No", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i){
                    Toast.makeText(ToolScreen.this, "All Good!", Toast.LENGTH_SHORT).show();
                }
            });
            alert.create().show();
        }

        floatingActionButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(ToolScreen.this, CreateItem.class);
                intent.putExtra("USER_NAME", userName);
                startActivity(intent);
            }
        });

    }
}

