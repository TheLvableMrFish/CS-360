package com.zybooks.cs360finalproject;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper{

    public static  final String DBNAME = "Login.db";
    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }


    public  void onCreate(SQLiteDatabase MyDB){
        MyDB.execSQL("create Table users(username Text primary key, password Text, notify INTEGER DEFAULT 0)");
    }

    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1){
        MyDB.execSQL("drop Table if exists users");
    }

    public Boolean insertData(String username, String password, Boolean notify){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("notify", notify ? 1 : 0);
        long result = MyDB.insert("users", null, contentValues);
        if(result == -1) return false;
        else
            return true;

    }

    public Boolean checkUserName(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users WHERE username = ?", new String[] {username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkUserNamePassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM users WHERE username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean updateNotifyStatus(String username, Boolean notify){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("notify", notify ? 1: 0);
        long result = MyDB.update("users", contentValues, "username=?", new String[]{username});
        if(result == -1) return false;
        else
            return true;
    }


    public Boolean getNotifyStatus(String username){
        if(username == null){
            return false;
        }

        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT notify FROM users WHERE username = ?", new String[]{username});

        Boolean notify = false;

        if(cursor.moveToFirst()){
            notify = cursor.getInt(cursor.getColumnIndex("notify")) == 1;
        }

        cursor.close();

        return notify;

    }
}
